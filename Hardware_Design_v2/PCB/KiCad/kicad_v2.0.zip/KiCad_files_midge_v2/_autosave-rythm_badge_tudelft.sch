EESchema Schematic File Version 5
EELAYER 46 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
Comment5 ""
Comment6 ""
Comment7 ""
Comment8 ""
Comment9 ""
$EndDescr
Connection ~ 1000 4400
Connection ~ 1000 4700
Connection ~ 1300 4400
Connection ~ 1900 2050
Connection ~ 2250 5250
Connection ~ 2350 5250
Connection ~ 2450 5250
Connection ~ 2550 2650
Connection ~ 2550 5250
Connection ~ 2650 5250
Connection ~ 2750 5250
Connection ~ 2850 5250
Connection ~ 2950 1600
Connection ~ 2950 5250
Connection ~ 3050 5250
Connection ~ 3150 5250
Connection ~ 4200 3500
Connection ~ 4200 4300
Connection ~ 4250 1000
Connection ~ 4300 3600
Connection ~ 4300 4200
Connection ~ 4650 2550
Connection ~ 4650 4700
Connection ~ 4650 6100
Connection ~ 4800 2250
Connection ~ 4850 3450
Connection ~ 4850 4700
Connection ~ 4850 6100
Connection ~ 5000 2250
Connection ~ 5050 2550
Connection ~ 5050 2750
Connection ~ 5050 3800
Connection ~ 5050 4000
Connection ~ 5050 5200
Connection ~ 5050 5400
Connection ~ 6750 1250
Connection ~ 6750 1450
Connection ~ 7050 1150
Connection ~ 7050 1450
Connection ~ 7500 5400
Connection ~ 7650 2100
Connection ~ 8250 2100
Connection ~ 8950 2700
Connection ~ 8950 2900
Connection ~ 9700 5600
Connection ~ 9700 5900
Connection ~ 10200 5200
NoConn ~ 1950 3500
NoConn ~ 1950 3600
NoConn ~ 1950 3800
NoConn ~ 1950 4000
NoConn ~ 1950 4300
NoConn ~ 1950 4500
NoConn ~ 1950 4600
NoConn ~ 1950 4700
NoConn ~ 2050 1300
NoConn ~ 2050 1400
NoConn ~ 2050 1500
NoConn ~ 2050 6250
NoConn ~ 2050 6350
NoConn ~ 2050 6450
NoConn ~ 3450 3200
NoConn ~ 3450 4100
NoConn ~ 3450 4200
NoConn ~ 3450 4300
NoConn ~ 3450 4400
NoConn ~ 3450 4500
NoConn ~ 3450 4600
NoConn ~ 7900 5100
NoConn ~ 7900 5200
NoConn ~ 9500 5500
NoConn ~ 9600 2400
NoConn ~ 9600 3100
Wire Wire Line
	1000 4350 1000 4400
Wire Wire Line
	1000 4400 1000 4450
Wire Wire Line
	1000 4700 1000 4650
Wire Wire Line
	1300 4400 1000 4400
Wire Wire Line
	1300 4400 1950 4400
Wire Wire Line
	1300 4450 1300 4400
Wire Wire Line
	1300 4650 1300 4700
Wire Wire Line
	1300 4700 1000 4700
Wire Wire Line
	1650 2050 1650 2000
Wire Wire Line
	1650 3200 1950 3200
Wire Wire Line
	1650 3400 1950 3400
Wire Wire Line
	1900 2050 1650 2050
Wire Wire Line
	1950 3300 1650 3300
Wire Wire Line
	2050 1600 2100 1600
Wire Wire Line
	2100 1600 2100 2050
Wire Wire Line
	2100 2050 1900 2050
Wire Wire Line
	2150 5100 2150 5250
Wire Wire Line
	2150 5250 2250 5250
Wire Wire Line
	2250 2500 2550 2500
Wire Wire Line
	2250 2550 2250 2500
Wire Wire Line
	2250 5100 2250 5250
Wire Wire Line
	2250 5250 2350 5250
Wire Wire Line
	2350 5250 2350 5100
Wire Wire Line
	2350 5250 2450 5250
Wire Wire Line
	2450 5100 2450 5250
Wire Wire Line
	2450 5250 2550 5250
Wire Wire Line
	2550 2500 2550 2650
Wire Wire Line
	2550 2650 2550 2900
Wire Wire Line
	2550 2650 2750 2650
Wire Wire Line
	2550 5100 2550 5250
Wire Wire Line
	2550 5250 2650 5250
Wire Wire Line
	2650 5100 2650 5250
Wire Wire Line
	2650 5250 2750 5250
Wire Wire Line
	2650 5400 2650 5250
Wire Wire Line
	2750 5100 2750 5250
Wire Wire Line
	2750 5250 2850 5250
Wire Wire Line
	2850 5100 2850 5250
Wire Wire Line
	2850 5250 2950 5250
Wire Wire Line
	2950 1350 2950 1000
Wire Wire Line
	2950 1550 2950 1600
Wire Wire Line
	2950 1600 3300 1600
Wire Wire Line
	2950 1800 2950 1600
Wire Wire Line
	2950 1800 3300 1800
Wire Wire Line
	2950 2650 3100 2650
Wire Wire Line
	2950 5100 2950 5250
Wire Wire Line
	2950 5250 3050 5250
Wire Wire Line
	3050 5100 3050 5250
Wire Wire Line
	3050 5250 3150 5250
Wire Wire Line
	3150 5100 3150 5250
Wire Wire Line
	3150 5250 3250 5250
Wire Wire Line
	3250 5250 3250 5100
Wire Wire Line
	3450 3500 4200 3500
Wire Wire Line
	3450 3600 4300 3600
Wire Wire Line
	3500 1800 3700 1800
Wire Wire Line
	3700 1600 3500 1600
Wire Wire Line
	4200 3050 4350 3050
Wire Wire Line
	4200 3500 4200 3050
Wire Wire Line
	4200 4300 4200 3500
Wire Wire Line
	4200 4300 4200 5700
Wire Wire Line
	4250 1000 2950 1000
Wire Wire Line
	4250 1000 5350 1000
Wire Wire Line
	4250 1100 4250 1000
Wire Wire Line
	4250 2250 4250 2150
Wire Wire Line
	4250 2550 4650 2550
Wire Wire Line
	4250 3150 4250 2550
Wire Wire Line
	4300 2950 4300 3600
Wire Wire Line
	4300 3600 4300 4200
Wire Wire Line
	4300 4200 4300 5600
Wire Wire Line
	4300 4200 4350 4200
Wire Wire Line
	4300 5600 4350 5600
Wire Wire Line
	4300 5800 4300 6100
Wire Wire Line
	4300 6100 4650 6100
Wire Wire Line
	4350 2950 4300 2950
Wire Wire Line
	4350 3150 4250 3150
Wire Wire Line
	4350 4300 4200 4300
Wire Wire Line
	4350 4400 4350 4700
Wire Wire Line
	4350 4700 4650 4700
Wire Wire Line
	4350 5700 4200 5700
Wire Wire Line
	4350 5800 4300 5800
Wire Wire Line
	4650 2550 4650 2650
Wire Wire Line
	4650 3800 4650 3900
Wire Wire Line
	4650 5200 4650 5300
Wire Wire Line
	4800 1400 5000 1400
Wire Wire Line
	4800 1700 4800 1850
Wire Wire Line
	4800 2050 4800 2250
Wire Wire Line
	4800 2250 4250 2250
Wire Wire Line
	4850 3450 4650 3450
Wire Wire Line
	4850 4700 4650 4700
Wire Wire Line
	4850 6100 4650 6100
Wire Wire Line
	5000 1400 5000 1450
Wire Wire Line
	5000 1650 5000 2250
Wire Wire Line
	5000 2250 4800 2250
Wire Wire Line
	5050 2550 4650 2550
Wire Wire Line
	5050 2750 5050 3450
Wire Wire Line
	5050 3450 4850 3450
Wire Wire Line
	5050 3800 4650 3800
Wire Wire Line
	5050 4000 5050 4700
Wire Wire Line
	5050 4700 4850 4700
Wire Wire Line
	5050 5200 4650 5200
Wire Wire Line
	5050 5400 5050 6100
Wire Wire Line
	5050 6100 4850 6100
Wire Wire Line
	5350 1000 5350 1200
Wire Wire Line
	5350 1400 5350 2250
Wire Wire Line
	5350 2250 5000 2250
Wire Wire Line
	5450 2550 5050 2550
Wire Wire Line
	5450 2750 5050 2750
Wire Wire Line
	5450 3800 5050 3800
Wire Wire Line
	5450 4000 5050 4000
Wire Wire Line
	5450 5200 5050 5200
Wire Wire Line
	5450 5400 5050 5400
Wire Wire Line
	6750 1150 7050 1150
Wire Wire Line
	6750 1250 6750 1150
Wire Wire Line
	6750 1450 6750 1250
Wire Wire Line
	6750 1700 6750 1450
Wire Wire Line
	6750 2100 6750 1900
Wire Wire Line
	6750 2100 7650 2100
Wire Wire Line
	7050 1150 7150 1150
Wire Wire Line
	7050 1250 7050 1150
Wire Wire Line
	7050 1450 6750 1450
Wire Wire Line
	7050 1550 7050 1450
Wire Wire Line
	7150 1250 7050 1250
Wire Wire Line
	7150 1450 7050 1450
Wire Wire Line
	7150 1550 7050 1550
Wire Wire Line
	7500 5000 7500 5400
Wire Wire Line
	7500 5400 7500 5700
Wire Wire Line
	7650 2100 7650 2000
Wire Wire Line
	7650 2100 8250 2100
Wire Wire Line
	7650 2250 7650 2100
Wire Wire Line
	7900 5000 7500 5000
Wire Wire Line
	7900 5400 7500 5400
Wire Wire Line
	8150 1150 8550 1150
Wire Wire Line
	8150 1450 8250 1450
Wire Wire Line
	8250 1450 8250 1500
Wire Wire Line
	8250 1700 8250 2100
Wire Wire Line
	8550 1150 8550 1200
Wire Wire Line
	8550 1400 8550 2100
Wire Wire Line
	8550 2100 8250 2100
Wire Wire Line
	8550 2900 8950 2900
Wire Wire Line
	8950 2700 8550 2700
Wire Wire Line
	9500 4700 10200 4700
Wire Wire Line
	9500 5300 9700 5300
Wire Wire Line
	9500 5600 9700 5600
Wire Wire Line
	9550 3600 9600 3600
Wire Wire Line
	9550 3700 9550 3600
Wire Wire Line
	9600 2700 8950 2700
Wire Wire Line
	9600 2900 8950 2900
Wire Wire Line
	9700 5300 9700 5350
Wire Wire Line
	9700 5550 9700 5600
Wire Wire Line
	9700 5600 9700 5900
Wire Wire Line
	9700 5900 9500 5900
Wire Wire Line
	9850 4800 9500 4800
Wire Wire Line
	9850 4850 9850 4800
Wire Wire Line
	9850 5050 9850 5200
Wire Wire Line
	9850 5200 10200 5200
Wire Wire Line
	10200 4700 10200 4750
Wire Wire Line
	10200 5200 10200 4950
Wire Wire Line
	10200 5200 10200 5900
Wire Wire Line
	10200 5900 9700 5900
Text Label 1000 4150 0    50   ~ 0
BAT
Text Label 1250 3300 2    50   ~ 0
3V3
Text Label 1550 6050 2    50   ~ 0
3V3
Text Label 1550 6150 2    50   ~ 0
GND
Text Label 1550 6250 2    50   ~ 0
GND
Text Label 1550 6350 2    50   ~ 0
GND
Text Label 1550 6450 2    50   ~ 0
GND
Text Label 1950 3100 2    50   ~ 0
SWCLK
Text Label 1950 3700 2    50   ~ 0
INT1
Text Label 1950 3900 2    50   ~ 0
SDA
Text Label 1950 4100 2    50   ~ 0
SCL
Text Label 1950 4200 2    50   ~ 0
LED_IND
Text Label 2050 1200 0    50   ~ 0
VBUS
Text Label 2050 6050 0    50   ~ 0
SWDIO
Text Label 2050 6150 0    50   ~ 0
SWCLK
Text Label 2550 2500 0    50   ~ 0
3V3
Text Label 3300 2650 0    50   ~ 0
LED_IND
Text Label 3450 3100 0    50   ~ 0
CD
Text Label 3450 3300 0    50   ~ 0
SW
Text Label 3450 3700 0    50   ~ 0
CS
Text Label 3450 3800 0    50   ~ 0
MOSI
Text Label 3450 3900 0    50   ~ 0
CLK
Text Label 3450 4000 0    50   ~ 0
MISO
Text Label 3450 4700 0    50   ~ 0
SWDIO
Text Label 4250 1000 0    50   ~ 0
VBUS
Text Label 4650 2550 0    50   ~ 0
3V3
Text Label 4650 3800 0    50   ~ 0
3V3
Text Label 4650 5200 0    50   ~ 0
3V3
Text Label 5000 1400 0    50   ~ 0
BAT
Text Label 6350 1150 2    50   ~ 0
BAT
Text Label 6350 1350 2    50   ~ 0
GND
Text Label 7100 3200 2    50   ~ 0
1V8
Text Label 7100 3400 2    50   ~ 0
INT1_1V8
Text Label 7100 3500 2    50   ~ 0
SDA_1V8
Text Label 7100 3600 2    50   ~ 0
SCL_1V8
Text Label 7100 3750 2    50   ~ 0
1V8
Text Label 7900 5300 2    50   ~ 0
SCL_1V8
Text Label 7900 5500 2    50   ~ 0
SDA_1V8
Text Label 7900 5600 2    50   ~ 0
1V8
Text Label 8100 3200 0    50   ~ 0
3V3
Text Label 8100 3400 0    50   ~ 0
INT1
Text Label 8100 3500 0    50   ~ 0
SDA
Text Label 8100 3600 0    50   ~ 0
SCL
Text Label 8250 1450 0    50   ~ 0
1V8
Text Label 8550 1150 0    50   ~ 0
3V3
Text Label 8950 2700 0    50   ~ 0
3V3
Text Label 9200 1150 2    50   ~ 0
BAT
Text Label 9200 1400 2    50   ~ 0
GND
Text Label 9500 5100 0    50   ~ 0
INT1_1V8
Text Label 9600 2500 2    50   ~ 0
CS
Text Label 9600 2600 2    50   ~ 0
MOSI
Text Label 9600 2800 2    50   ~ 0
CLK
Text Label 9600 3000 2    50   ~ 0
MISO
Text Label 9600 3300 2    50   ~ 0
CD
Text Label 9600 3400 2    50   ~ 0
SW
Text Label 9850 4800 0    50   ~ 0
1V8
Text Label 10200 4700 0    50   ~ 0
1V8
$Comp
L rythm_badge_tudelft-rescue:Conn_01x01_Female-Connector J4
U 1 1 5D2B1AD2
P 9400 1150
F 0 "J4" H 9428 1176 50  0000 L CNN
F 1 "BAT+" H 9428 1085 50  0000 L CNN
F 2 "Connector_Wire:SolderWirePad_1x01_Drill1.2mm" H 9400 1150 50  0001 C CNN
F 3 "~" H 9400 1150 50  0001 C CNN
F 4 "" H 9400 1150 50  0001 C CNN
	1    9400 1150
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:Conn_01x01_Female-Connector J5
U 1 1 5D2B1C81
P 9400 1400
F 0 "J5" H 9428 1426 50  0000 L CNN
F 1 "BAT-" H 9428 1335 50  0000 L CNN
F 2 "Connector_Wire:SolderWirePad_1x01_Drill1.2mm" H 9400 1400 50  0001 C CNN
F 3 "~" H 9400 1400 50  0001 C CNN
F 4 "" H 9400 1400 50  0001 C CNN
	1    9400 1400
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR01
U 1 1 5D19AEEA
P 1000 4700
F 0 "#PWR01" H 1000 4450 50  0001 C CNN
F 1 "GND" H 1005 4527 50  0000 C CNN
F 2 "" H 1000 4700 50  0001 C CNN
F 3 "" H 1000 4700 50  0001 C CNN
F 4 "" H 1000 4700 50  0001 C CNN
	1    1000 4700
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR0101
U 1 1 5D791422
P 1900 2050
F 0 "#PWR0101" H 1900 1800 50  0001 C CNN
F 1 "GND" H 1905 1877 50  0000 C CNN
F 2 "" H 1900 2050 50  0001 C CNN
F 3 "" H 1900 2050 50  0001 C CNN
F 4 "" H 1900 2050 50  0001 C CNN
	1    1900 2050
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR03
U 1 1 5D142F36
P 2250 2750
F 0 "#PWR03" H 2250 2500 50  0001 C CNN
F 1 "GND" H 2255 2577 50  0000 C CNN
F 2 "" H 2250 2750 50  0001 C CNN
F 3 "" H 2250 2750 50  0001 C CNN
F 4 "" H 2250 2750 50  0001 C CNN
	1    2250 2750
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR04
U 1 1 5D141F21
P 2650 5400
F 0 "#PWR04" H 2650 5150 50  0001 C CNN
F 1 "GND" H 2655 5227 50  0000 C CNN
F 2 "" H 2650 5400 50  0001 C CNN
F 3 "" H 2650 5400 50  0001 C CNN
F 4 "" H 2650 5400 50  0001 C CNN
	1    2650 5400
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR07
U 1 1 5D13A50E
P 4800 2250
F 0 "#PWR07" H 4800 2000 50  0001 C CNN
F 1 "GND" H 4805 2077 50  0000 C CNN
F 2 "" H 4800 2250 50  0001 C CNN
F 3 "" H 4800 2250 50  0001 C CNN
F 4 "" H 4800 2250 50  0001 C CNN
	1    4800 2250
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR08
U 1 1 5D17A9E7
P 4850 3450
F 0 "#PWR08" H 4850 3200 50  0001 C CNN
F 1 "GND" H 4855 3277 50  0000 C CNN
F 2 "" H 4850 3450 50  0001 C CNN
F 3 "" H 4850 3450 50  0001 C CNN
F 4 "" H 4850 3450 50  0001 C CNN
	1    4850 3450
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR09
U 1 1 5D17C166
P 4850 4700
F 0 "#PWR09" H 4850 4450 50  0001 C CNN
F 1 "GND" H 4855 4527 50  0000 C CNN
F 2 "" H 4850 4700 50  0001 C CNN
F 3 "" H 4850 4700 50  0001 C CNN
F 4 "" H 4850 4700 50  0001 C CNN
	1    4850 4700
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR02
U 1 1 5D6457CD
P 4850 6100
F 0 "#PWR02" H 4850 5850 50  0001 C CNN
F 1 "GND" H 4855 5927 50  0000 C CNN
F 2 "" H 4850 6100 50  0001 C CNN
F 3 "" H 4850 6100 50  0001 C CNN
F 4 "" H 4850 6100 50  0001 C CNN
	1    4850 6100
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR010
U 1 1 5D66BE04
P 7500 5700
F 0 "#PWR010" H 7500 5450 50  0001 C CNN
F 1 "GND" H 7505 5527 50  0000 C CNN
F 2 "" H 7500 5700 50  0001 C CNN
F 3 "" H 7500 5700 50  0001 C CNN
F 4 "" H 7500 5700 50  0001 C CNN
	1    7500 5700
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR013
U 1 1 5D676F69
P 7600 4000
F 0 "#PWR013" H 7600 3750 50  0001 C CNN
F 1 "GND" H 7605 3827 50  0000 C CNN
F 2 "" H 7600 4000 50  0001 C CNN
F 3 "" H 7600 4000 50  0001 C CNN
F 4 "" H 7600 4000 50  0001 C CNN
	1    7600 4000
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR011
U 1 1 5D13A4B2
P 7650 2250
F 0 "#PWR011" H 7650 2000 50  0001 C CNN
F 1 "GND" H 7655 2077 50  0000 C CNN
F 2 "" H 7650 2250 50  0001 C CNN
F 3 "" H 7650 2250 50  0001 C CNN
F 4 "" H 7650 2250 50  0001 C CNN
	1    7650 2250
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR05
U 1 1 5D1D6D88
P 8950 2900
F 0 "#PWR05" H 8950 2650 50  0001 C CNN
F 1 "GND" H 8955 2727 50  0000 C CNN
F 2 "" H 8950 2900 50  0001 C CNN
F 3 "" H 8950 2900 50  0001 C CNN
F 4 "" H 8950 2900 50  0001 C CNN
	1    8950 2900
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR06
U 1 1 5D1BDE63
P 9550 3700
F 0 "#PWR06" H 9550 3450 50  0001 C CNN
F 1 "GND" H 9555 3527 50  0000 C CNN
F 2 "" H 9550 3700 50  0001 C CNN
F 3 "" H 9550 3700 50  0001 C CNN
F 4 "" H 9550 3700 50  0001 C CNN
	1    9550 3700
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:GND-power #PWR014
U 1 1 5D1E5D7D
P 9700 5900
F 0 "#PWR014" H 9700 5650 50  0001 C CNN
F 1 "GND" H 9705 5727 50  0000 C CNN
F 2 "" H 9700 5900 50  0001 C CNN
F 3 "" H 9700 5900 50  0001 C CNN
F 4 "" H 9700 5900 50  0001 C CNN
	1    9700 5900
	1    0    0    -1  
$EndComp
$Comp
L Device:R_Small R1
U 1 1 5D18C27D
P 1000 4250
F 0 "R1" H 1059 4296 50  0000 L CNN
F 1 "10M" H 1059 4205 50  0000 L CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 1000 4250 50  0001 C CNN
F 3 "~" H 1000 4250 50  0001 C CNN
F 4 "" H 1000 4250 50  0001 C CNN
F 5 "CRCW060310M0FKEAC" H 0   0   50  0001 C CNN "MPN"
F 6 "Vishay / Dale" H 0   0   50  0001 C CNN "Manufacturer"
	1    1000 4250
	1    0    0    -1  
$EndComp
$Comp
L Device:R_Small R2
U 1 1 5D18C1E1
P 1000 4550
F 0 "R2" H 1059 4596 50  0000 L CNN
F 1 "10M" H 1059 4505 50  0000 L CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 1000 4550 50  0001 C CNN
F 3 "~" H 1000 4550 50  0001 C CNN
F 4 "" H 1000 4550 50  0001 C CNN
F 5 "CRCW060310M0FKEAC" H 0   0   50  0001 C CNN "MPN"
F 6 "Vishay / Dale" H 0   0   50  0001 C CNN "Manufacturer"
	1    1000 4550
	1    0    0    -1  
$EndComp
$Comp
L Device:R_Small R5
U 1 1 5D1B4D61
P 2850 2650
F 0 "R5" V 2654 2650 50  0000 C CNN
F 1 "2k" V 2745 2650 50  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 2850 2650 50  0001 C CNN
F 3 "~" H 2850 2650 50  0001 C CNN
F 4 "" H 2850 2650 50  0001 C CNN
F 5 "CRCW06032K00FKEAC" H 0   0   50  0001 C CNN "MPN"
F 6 "Vishay / Dale" H 0   0   50  0001 C CNN "Manufacturer"
	1    2850 2650
	0    1    1    0   
$EndComp
$Comp
L Device:R_Small R4
U 1 1 5D28BDA5
P 2950 1450
F 0 "R4" H 2891 1404 50  0000 R CNN
F 1 "1k" H 2891 1495 50  0000 R CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 2950 1450 50  0001 C CNN
F 3 "~" H 2950 1450 50  0001 C CNN
F 4 "" H 2950 1450 50  0001 C CNN
F 5 "CRCW06031K00FKEAC" H 0   0   50  0001 C CNN "MPN"
F 6 "Vishay / Dale" H 0   0   50  0001 C CNN "Manufacturer"
	1    2950 1450
	-1   0    0    1   
$EndComp
$Comp
L Device:R_Small R6
U 1 1 5D13B1A6
P 4800 1950
F 0 "R6" H 4859 1996 50  0000 L CNN
F 1 "3k" H 4859 1905 50  0000 L CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 4800 1950 50  0001 C CNN
F 3 "~" H 4800 1950 50  0001 C CNN
F 4 "" H 4800 1950 50  0001 C CNN
F 5 "CRCW06033K00FKEAC" H 0   0   50  0001 C CNN "MPN"
F 6 "Vishay / Dale" H 0   0   50  0001 C CNN "Manufacturer"
	1    4800 1950
	1    0    0    -1  
$EndComp
$Comp
L Device:LED_Small D3
U 1 1 5D139909
P 3200 2650
F 0 "D3" H 3246 2582 50  0000 R CNN
F 1 "Orange" H 3300 2500 50  0000 R CNN
F 2 "LED_SMD:LED_0603_1608Metric" V 3200 2650 50  0001 C CNN
F 3 "~" V 3200 2650 50  0001 C CNN
F 4 "" H 3200 2650 50  0001 C CNN
F 5 "SML-D12D1WT86" H 0   0   50  0001 C CNN "MPN"
F 6 "Rohm Semiconductor" H 0   0   50  0001 C CNN "Manufacturer"
	1    3200 2650
	-1   0    0    1   
$EndComp
$Comp
L Device:LED_Small D1
U 1 1 5D28BAE6
P 3400 1600
F 0 "D1" H 3400 1395 50  0000 C CNN
F 1 "Red" H 3400 1486 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" V 3400 1600 50  0001 C CNN
F 3 "~" V 3400 1600 50  0001 C CNN
F 4 "" H 3400 1600 50  0001 C CNN
F 5 "SML-D12V1WT86" H 0   0   50  0001 C CNN "MPN"
F 6 "Rohm Semiconductor" H 0   0   50  0001 C CNN "Manufacturer"
	1    3400 1600
	-1   0    0    1   
$EndComp
$Comp
L Device:LED_Small D2
U 1 1 5D28BA06
P 3400 1800
F 0 "D2" H 3400 1950 50  0000 C CNN
F 1 "Green" H 3400 2050 50  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric" V 3400 1800 50  0001 C CNN
F 3 "~" V 3400 1800 50  0001 C CNN
F 4 "" H 3400 1800 50  0001 C CNN
F 5 "SML-D12M8WT86" H 0   0   50  0001 C CNN "MPN"
F 6 "Rohm Semiconductor" H 0   0   50  0001 C CNN "Manufacturer"
	1    3400 1800
	-1   0    0    1   
$EndComp
$Comp
L Device:C_Small C1
U 1 1 5D18C16D
P 1300 4550
F 0 "C1" H 1392 4596 50  0000 L CNN
F 1 "100nF" H 1392 4505 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 1300 4550 50  0001 C CNN
F 3 "~" H 1300 4550 50  0001 C CNN
F 4 "" H 1300 4550 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    1300 4550
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C2
U 1 1 5D142655
P 2250 2650
F 0 "C2" H 2342 2696 50  0000 L CNN
F 1 "10uF" H 2342 2605 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 2250 2650 50  0001 C CNN
F 3 "~" H 2250 2650 50  0001 C CNN
F 4 "" H 2250 2650 50  0001 C CNN
F 5 "JMK107ABJ106MA-T" H 0   0   50  0001 C CNN "MPN"
F 6 "Taiyo Yuden" H 0   0   50  0001 C CNN "Manufacturer"
	1    2250 2650
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C5
U 1 1 5D13A940
P 5000 1550
F 0 "C5" H 5092 1596 50  0000 L CNN
F 1 "10uF" H 5092 1505 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5000 1550 50  0001 C CNN
F 3 "~" H 5000 1550 50  0001 C CNN
F 4 "" H 5000 1550 50  0001 C CNN
F 5 "JMK107ABJ106MA-T" H 0   0   50  0001 C CNN "MPN"
F 6 "Taiyo Yuden" H 0   0   50  0001 C CNN "Manufacturer"
	1    5000 1550
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C6
U 1 1 5D1782E0
P 5050 2650
F 0 "C6" H 5142 2696 50  0000 L CNN
F 1 "1uF" H 5142 2605 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5050 2650 50  0001 C CNN
F 3 "~" H 5050 2650 50  0001 C CNN
F 4 "" H 5050 2650 50  0001 C CNN
F 5 "CL10B105KQ8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    5050 2650
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C7
U 1 1 5D17C150
P 5050 3900
F 0 "C7" H 5142 3946 50  0000 L CNN
F 1 "1uF" H 5142 3855 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5050 3900 50  0001 C CNN
F 3 "~" H 5050 3900 50  0001 C CNN
F 4 "" H 5050 3900 50  0001 C CNN
F 5 "CL10B105KQ8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    5050 3900
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C17
U 1 1 5D6457B7
P 5050 5300
F 0 "C17" H 5142 5346 50  0000 L CNN
F 1 "1uF" H 5142 5255 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5050 5300 50  0001 C CNN
F 3 "~" H 5050 5300 50  0001 C CNN
F 4 "" H 5050 5300 50  0001 C CNN
F 5 "CL10B105KQ8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    5050 5300
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C8
U 1 1 5D13B08B
P 5350 1300
F 0 "C8" H 5442 1346 50  0000 L CNN
F 1 "1uF" H 5442 1255 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5350 1300 50  0001 C CNN
F 3 "~" H 5350 1300 50  0001 C CNN
F 4 "" H 5350 1300 50  0001 C CNN
F 5 "CL10B105KQ8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    5350 1300
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C9
U 1 1 5D1783BA
P 5450 2650
F 0 "C9" H 5542 2696 50  0000 L CNN
F 1 "100nF" H 5542 2605 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5450 2650 50  0001 C CNN
F 3 "~" H 5450 2650 50  0001 C CNN
F 4 "" H 5450 2650 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    5450 2650
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C10
U 1 1 5D17C157
P 5450 3900
F 0 "C10" H 5542 3946 50  0000 L CNN
F 1 "100nF" H 5542 3855 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5450 3900 50  0001 C CNN
F 3 "~" H 5450 3900 50  0001 C CNN
F 4 "" H 5450 3900 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    5450 3900
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C18
U 1 1 5D6457BE
P 5450 5300
F 0 "C18" H 5542 5346 50  0000 L CNN
F 1 "100nF" H 5542 5255 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 5450 5300 50  0001 C CNN
F 3 "~" H 5450 5300 50  0001 C CNN
F 4 "" H 5450 5300 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    5450 5300
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C11
U 1 1 5D13A8DA
P 6750 1800
F 0 "C11" H 6842 1846 50  0000 L CNN
F 1 "1uF" H 6842 1755 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 6750 1800 50  0001 C CNN
F 3 "~" H 6750 1800 50  0001 C CNN
F 4 "" H 6750 1800 50  0001 C CNN
F 5 "CL10B105KQ8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    6750 1800
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C12
U 1 1 5D13B264
P 8250 1600
F 0 "C12" H 8342 1646 50  0000 L CNN
F 1 "1uF" H 8342 1555 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 8250 1600 50  0001 C CNN
F 3 "~" H 8250 1600 50  0001 C CNN
F 4 "" H 8250 1600 50  0001 C CNN
F 5 "CL10B105KQ8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    8250 1600
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C13
U 1 1 5D5F790D
P 8550 1300
F 0 "C13" H 8642 1346 50  0000 L CNN
F 1 "1uF" H 8642 1255 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 8550 1300 50  0001 C CNN
F 3 "~" H 8550 1300 50  0001 C CNN
F 4 "" H 8550 1300 50  0001 C CNN
F 5 "CL10B105KQ8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    8550 1300
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C3
U 1 1 5D1C7E86
P 8550 2800
F 0 "C3" H 8642 2846 50  0000 L CNN
F 1 "10uF" H 8642 2755 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 8550 2800 50  0001 C CNN
F 3 "~" H 8550 2800 50  0001 C CNN
F 4 "" H 8550 2800 50  0001 C CNN
F 5 "JMK107ABJ106MA-T" H 0   0   50  0001 C CNN "MPN"
F 6 "Taiyo Yuden" H 0   0   50  0001 C CNN "Manufacturer"
	1    8550 2800
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C4
U 1 1 5D1C7E08
P 8950 2800
F 0 "C4" H 9042 2846 50  0000 L CNN
F 1 "100nF" H 9042 2755 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 8950 2800 50  0001 C CNN
F 3 "~" H 8950 2800 50  0001 C CNN
F 4 "" H 8950 2800 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    8950 2800
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C14
U 1 1 5D62F511
P 9700 5450
F 0 "C14" H 9792 5496 50  0000 L CNN
F 1 "100nF" H 9792 5405 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 9700 5450 50  0001 C CNN
F 3 "~" H 9700 5450 50  0001 C CNN
F 4 "" H 9700 5450 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    9700 5450
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C15
U 1 1 5D62F4AD
P 9850 4950
F 0 "C15" H 9942 4996 50  0000 L CNN
F 1 "100nF" H 9942 4905 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 9850 4950 50  0001 C CNN
F 3 "~" H 9850 4950 50  0001 C CNN
F 4 "" H 9850 4950 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    9850 4950
	1    0    0    -1  
$EndComp
$Comp
L Device:C_Small C16
U 1 1 5D1E5DD6
P 10200 4850
F 0 "C16" H 10292 4896 50  0000 L CNN
F 1 "100nF" H 10292 4805 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 10200 4850 50  0001 C CNN
F 3 "~" H 10200 4850 50  0001 C CNN
F 4 "" H 10200 4850 50  0001 C CNN
F 5 "CL10B104KB8NNNC" H 0   0   50  0001 C CNN "MPN"
F 6 "Samsung Electro-Mechanics" H 0   0   50  0001 C CNN "Manufacturer"
	1    10200 4850
	1    0    0    -1  
$EndComp
$Comp
L Switch:SW_SP3T SW2
U 1 1 5D71FCE8
P 1450 3300
F 0 "SW2" H 1450 3583 50  0000 C CNN
F 1 "OFF-0,7k-HI" H 1450 3492 50  0000 C CNN
F 2 "Button_Switch_SMD:SW_SP3T_PCM13" H 825 3475 50  0001 C CNN
F 3 "" H 825 3475 50  0001 C CNN
F 4 "" H 1450 3300 50  0001 C CNN
F 5 "PCM13SMTR" H 0   0   50  0001 C CNN "MPN"
F 6 "C&K Switches" H 0   0   50  0001 C CNN "Manufacturer"
	1    1450 3300
	1    0    0    -1  
$EndComp
$Comp
L Switch:SW_SPDT SW1
U 1 1 5D60A4A3
P 6550 1250
F 0 "SW1" H 6550 925 50  0000 C CNN
F 1 "OFF - ON" H 6550 1016 50  0000 C CNN
F 2 "Button_Switch_SMD:SW_SPDT_PCM12" H 6550 1250 50  0001 C CNN
F 3 "" H 6550 1250 50  0001 C CNN
F 4 "" H 6550 1250 50  0001 C CNN
F 5 "PCM12SMTR" H 0   0   50  0001 C CNN "MPN"
F 6 "C&K Switches" H 0   0   50  0001 C CNN "Manufacturer"
	1    6550 1250
	-1   0    0    1   
$EndComp
$Comp
L Connector_Generic:Conn_02x05_Odd_Even J2
U 1 1 5D2B090B
P 1750 6250
F 0 "J2" H 1800 6667 50  0000 C CNN
F 1 "SWD" H 1800 6576 50  0000 C CNN
F 2 "Connector_PinHeader_1.27mm:PinHeader_2x05_P1.27mm_Vertical" H 1750 6250 50  0001 C CNN
F 3 "~" H 1750 6250 50  0001 C CNN
F 4 "" H 1750 6250 50  0001 C CNN
	1    1750 6250
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:MP34DT05-A-MP34DT05-A U2
U 1 1 5D110036
P 4650 3050
F 0 "U2" H 4650 3050 50  0001 L BNN
F 1 "MP34DT05-A" H 4650 3050 50  0001 L BNN
F 2 "custom_libs:MP34DT06" H 4650 3050 50  0001 L BNN
F 3 "None" H 4650 3050 50  0001 L BNN
F 4 "" H 4650 3050 50  0001 C CNN
F 5 "MP34DT05-A" H 4650 3050 50  0001 L BNN "Field4"
F 6 "Mic Omni-Directional -26dB 3.6Vdc Rectangular Solder Pad" H 4650 3050 50  0001 L BNN "Field5"
F 7 "Unavailable" H 4650 3050 50  0001 L BNN "Field6"
F 8 "None" H 4650 3050 50  0001 L BNN "Field7"
F 9 "STMicroelectronics" H 4650 3050 50  0001 L BNN "Field8"
F 10 "MP34DT05TR-A" H 0   0   50  0001 C CNN "MPN"
F 11 "STMicroelectronics" H 0   0   50  0001 C CNN "Manufacturer"
	1    4650 3050
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:MP34DT05-A-MP34DT05-A U3
U 1 1 5D17C14A
P 4650 4300
F 0 "U3" H 4650 4300 50  0001 L BNN
F 1 "MP34DT05-A" H 4650 4300 50  0001 L BNN
F 2 "custom_libs:MP34DT06" H 4650 4300 50  0001 L BNN
F 3 "None" H 4650 4300 50  0001 L BNN
F 4 "" H 4650 4300 50  0001 C CNN
F 5 "MP34DT05-A" H 4650 4300 50  0001 L BNN "Field4"
F 6 "Mic Omni-Directional -26dB 3.6Vdc Rectangular Solder Pad" H 4650 4300 50  0001 L BNN "Field5"
F 7 "Unavailable" H 4650 4300 50  0001 L BNN "Field6"
F 8 "None" H 4650 4300 50  0001 L BNN "Field7"
F 9 "STMicroelectronics" H 4650 4300 50  0001 L BNN "Field8"
F 10 "MP34DT05TR-A" H 0   0   50  0001 C CNN "MPN"
F 11 "STMicroelectronics" H 0   0   50  0001 C CNN "Manufacturer"
	1    4650 4300
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:MP34DT05-A-MP34DT05-A U7
U 1 1 5D6457B1
P 4650 5700
F 0 "U7" H 4650 5700 50  0001 L BNN
F 1 "MP34DT05-A" H 4650 5700 50  0001 L BNN
F 2 "custom_libs:MP34DT06" H 4650 5700 50  0001 L BNN
F 3 "None" H 4650 5700 50  0001 L BNN
F 4 "" H 4650 5700 50  0001 C CNN
F 5 "MP34DT05-A" H 4650 5700 50  0001 L BNN "Field4"
F 6 "Mic Omni-Directional -26dB 3.6Vdc Rectangular Solder Pad" H 4650 5700 50  0001 L BNN "Field5"
F 7 "Unavailable" H 4650 5700 50  0001 L BNN "Field6"
F 8 "None" H 4650 5700 50  0001 L BNN "Field7"
F 9 "STMicroelectronics" H 4650 5700 50  0001 L BNN "Field8"
F 10 "MP34DT05TR-A" H 0   0   50  0001 C CNN "MPN"
F 11 "STMicroelectronics" H 0   0   50  0001 C CNN "Manufacturer"
	1    4650 5700
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:10118194-0001LF-dk_USB-DVI-HDMI-Connectors J1
U 1 1 5D7A6C7F
P 1750 1400
F 0 "J1" H 1813 2145 60  0000 C CNN
F 1 "10118194-0001LF" H 1813 2039 60  0000 C CNN
F 2 "digikey-footprints:USB_Micro_B_Female_10118194-0001LF" H 1950 1600 60  0001 L CNN
F 3 "http://www.amphenol-icc.com/media/wysiwyg/files/drawing/10118194.pdf" H 1950 1700 60  0001 L CNN
F 4 "" H 1750 1400 50  0001 C CNN
F 5 "609-4618-1-ND" H 1950 1800 60  0001 L CNN "Digi-Key_PN"
F 6 "10118194-0011LF" H 1950 1900 60  0001 L CNN "MPN"
F 7 "Connectors, Interconnects" H 1950 2000 60  0001 L CNN "Category"
F 8 "USB, DVI, HDMI Connectors" H 1950 2100 60  0001 L CNN "Family"
F 9 "http://www.amphenol-icc.com/media/wysiwyg/files/drawing/10118194.pdf" H 1950 2200 60  0001 L CNN "DK_Datasheet_Link"
F 10 "/product-detail/en/amphenol-icc-fci/10118194-0001LF/609-4618-1-ND/2785382" H 1950 2300 60  0001 L CNN "DK_Detail_Page"
F 11 "CONN RCPT USB2.0 MICRO B SMD R/A" H 1950 2400 60  0001 L CNN "Description"
F 12 "Amphenol ICC (FCI)" H 1950 2500 60  0001 L CNN "Manufacturer"
F 13 "Active" H 1950 2600 60  0001 L CNN "Status"
	1    1750 1400
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:NTS0104-Custom_parts U6
U 1 1 5D616EEB
P 7600 3450
F 0 "U6" H 7600 3965 50  0000 C CNN
F 1 "NTS0104" H 7600 3874 50  0000 C CNN
F 2 "QFN50PX250X300X100-15N:QFN50PX250X300X100-15N" H 7600 3450 50  0001 C CNN
F 3 "" H 7600 3450 50  0001 C CNN
F 4 "" H 7600 3450 50  0001 C CNN
F 5 "NTS0104BQ,115" H 0   0   50  0001 C CNN "MPN"
F 6 "NXP" H 0   0   50  0001 C CNN "Manufacturer"
	1    7600 3450
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:AP7345D-Custom_parts U4
U 1 1 5D5E5932
P 7650 1350
F 0 "U4" H 7800 800 50  0000 C CNN
F 1 "AP7345D" H 7650 1724 50  0000 C CNN
F 2 "Package_DFN_QFN:X2-DFN1612-8" H 7500 1450 50  0001 C CNN
F 3 "" H 7500 1450 50  0001 C CNN
F 4 "" H 7650 1350 50  0001 C CNN
F 5 "AP7345D-3318RH4-7" H 0   0   50  0001 C CNN "MPN"
F 6 "Diodes Incorporated" H 0   0   50  0001 C CNN "Manufacturer"
	1    7650 1350
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:503182-1852-503182-1852 J3
U 1 1 5D2EB9B5
P 9800 3000
F 0 "J3" H 10329 3046 50  0000 L CNN
F 1 "503182-1852" H 10329 2955 50  0000 L CNN
F 2 "503182-1852:MOLEX_503182-1852" H 9800 3000 50  0001 L BNN
F 3 "WM12834CT-ND" H 9800 3000 50  0001 L BNN
F 4 "" H 9800 3000 50  0001 C CNN
F 5 "Molex" H 9800 3000 50  0001 L BNN "Field4"
F 6 "MICRO SD NORMAL ULTRALOWPRO8CKTE" H 9800 3000 50  0001 L BNN "Field5"
F 7 "https://www.digikey.com/product-detail/en/molex/5031821852/WM12834CT-ND/5823232?utm_source=snapeda&utm_medium=aggregator&utm_campaign=symbol" H 9800 3000 50  0001 L BNN "Field6"
F 8 "5031821852" H 9800 3000 50  0001 L BNN "Field7"
F 9 "None" H 9800 3000 50  0001 L BNN "Field8"
F 10 "503182-1852" H 0   0   50  0001 C CNN "MPN"
F 11 "Molex" H 0   0   50  0001 C CNN "Manufacturer"
	1    9800 3000
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:TP4057-Custom_parts U1
U 1 1 5D1399B1
P 4200 1650
F 0 "U1" H 3950 2050 50  0000 C CNN
F 1 "TP4057" H 4500 2100 50  0000 C CNN
F 2 "Package_TO_SOT_SMD:SOT-23-6" H 4150 2150 50  0001 C CNN
F 3 "" H 4150 2150 50  0001 C CNN
F 4 "" H 4200 1650 50  0001 C CNN
F 5 "TP4057-42-SOT26-R" H 0   0   50  0001 C CNN "MPN"
F 6 "Nanjing Extension Microelectronics" H 0   0   50  0001 C CNN "Manufacturer"
	1    4200 1650
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:ICM-20948-ICM-20948 U5
U 1 1 5D61ABD2
P 8700 5300
F 0 "U5" H 8700 6165 50  0000 C CNN
F 1 "ICM-20948" H 8700 6074 50  0000 C CNN
F 2 "ICM-20948:QFN40P300X300X105-24N" H 8700 5300 50  0001 L BNN
F 3 "https://www.digikey.com/product-detail/en/tdk-invensense/ICM-20948/1428-1123-1-ND/7062698?utm_source=snapeda&utm_medium=aggregator&utm_campaign=symbol" H 8700 5300 50  0001 L BNN
F 4 "" H 8700 5300 50  0001 C CNN
F 5 "9 Axis=3 Axis Gyro+3 Axis Accel+Compass. Pin For Pin With m" H 8700 5300 50  0001 L BNN "Field4"
F 6 "TDK InvenSense" H 8700 5300 50  0001 L BNN "Field5"
F 7 "1428-1123-1-ND" H 8700 5300 50  0001 L BNN "Field6"
F 8 "ICM-20948" H 8700 5300 50  0001 L BNN "Field7"
F 9 "QFN-24 InvenSense" H 8700 5300 50  0001 L BNN "Field8"
F 10 "ICM-20948" H 0   0   50  0001 C CNN "MPN"
F 11 "TDK" H 0   0   50  0001 C CNN "Manufacturer"
	1    8700 5300
	1    0    0    -1  
$EndComp
$Comp
L rythm_badge_tudelft-rescue:BMD-300-A-R-dk_RF-Transceiver-Modules MOD1
U 1 1 5D10E9A6
P 2650 4100
F 0 "MOD1" H 1850 3300 60  0000 C CNN
F 1 "BMD-300-A-R" H 3000 5300 60  0000 C CNN
F 2 "digikey-footprints:Bluetooth_Module_BMD-300" H 2850 4300 60  0001 L CNN
F 3 "http://go.rigado.com/BMD-300-Data-Sheet" H 2850 4400 60  0001 L CNN
F 4 "" H 2650 4100 50  0001 C CNN
F 5 "1604-1006-1-ND" H 2850 4500 60  0001 L CNN "Digi-Key_PN"
F 6 "BMD-300-A-R" H 2850 4600 60  0001 L CNN "MPN"
F 7 "RF/IF and RFID" H 2850 4700 60  0001 L CNN "Category"
F 8 "RF Transceiver Modules" H 2850 4800 60  0001 L CNN "Family"
F 9 "http://go.rigado.com/BMD-300-Data-Sheet" H 2850 4900 60  0001 L CNN "DK_Datasheet_Link"
F 10 "/product-detail/en/rigado-inc/BMD-300-A-R/1604-1006-1-ND/5878285" H 2850 5000 60  0001 L CNN "DK_Detail_Page"
F 11 "MOD BLE 5.0 NORDIC NRF52832 SOC" H 2850 5100 60  0001 L CNN "Description"
F 12 "Rigado, Inc." H 2850 5200 60  0001 L CNN "Manufacturer"
F 13 "Active" H 2850 5300 60  0001 L CNN "Status"
	1    2650 4100
	1    0    0    -1  
$EndComp
$EndSCHEMATC
